# DESKRIPSI PROJECT
SPK adalah Sistem Pengambilan Keputusan yang dimana kasus pengambilan keputusan yang diambil dikasus ini adalah Pemilihan tempat les. Untuk metode yang digunakan pada kasus ini adalah metode <b>Weighted product</b>.
Bahasa pemrograman yang dipakai adalah PHP. Untuk tampilannya menggunakan Framework <b>Bulma</b>.

# TUJUAN
Tujuan pembuatan project SPK ini adalah untuk memenuhi nilai UTS dari matakuliah SPK (Sistem Pengambilan Keputusan).

# INSTALASI
Jalanin XAMPP, terus buka localhost -> phpmyadmin. Kalo udah, buat db dengan nama belajar. Kalo udah buat, langsung klik import pilih file yang ada didalem folder database.

# BACA INI
Sebelum download, pastikan kalian mempunyai :
* Code Editor (Boleh VS Code, Sublime, Notepad++ dsb).
* XAMPP (Ini butuh banget, untuk import database).
* Kalo udah ada 2 poin diatas, langsung download aja projectnya <b>GRATIS</b>.
# spk_restaurant_wp
