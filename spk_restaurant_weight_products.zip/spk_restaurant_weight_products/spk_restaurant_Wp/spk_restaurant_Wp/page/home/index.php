<section class="hero is-medium is-bold" style="background: linear-gradient(to right, #9900cc, #3366ff);">
    <div class="hero-body">
        <div class="container">
            <h1 class="title animate__animated animate__zoomIn has-text-white">
                SPK RESTAURANT
            </h1>
            <h2 class="subtitle animate__animated animate__slideInUp has-text-white">
                By Kelompok 4
            </h2>
        </div>
    </div>
</section>
