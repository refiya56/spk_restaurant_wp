<?php
require("../controller/Kriteria.php");

$kriteria = Index("SELECT * FROM kriteria");
$alternatif = Index("SELECT * FROM alternatif");
$bobot = Index("SELECT * FROM pembobotan");
$maxkriteria = Index("SELECT SUM(bobot) AS Total FROM kriteria");
$test = [];
$varV = [];
$totalS = 0;
?>
<section class="section">
    <div class="container">
        <div class="row">
            <div class="columns">
                <div class="column">
                    <div class="card animate__animated animate__zoomIn">
                        <div class="card-header">
                            <p class="card-header-title">Table Penilaian</p>
                        </div>
                        <div class="card-content">
                            <div class="table-container">
                                <table class="table is-fullwidth">
                                    <thead>
                                        <tr style="background-color: #7D0541; color: white;">
                                            <th style="color: white;">No</th>
                                            <th style="color: white;">Alternatif</th>
                                            <?php foreach ($kriteria as $header) : ?>
                                                <?php if ($header["nm_kriteria"] === "Kualitas Pengajar") : ?>
                                                    <th style="color: white;">Pelayanan</th>
                                                <?php elseif ($header["nm_kriteria"] === "Fasilitas") : ?>
                                                    <th style="color: white;">Makanan</th>
                                                <?php else : ?>
                                                    <th style="color: white;"><?= $header["nm_kriteria"] ?></th>
                                                <?php endif; ?>
                                            <?php endforeach ?>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr style="background-color: #7D0541; color: white;">
                                            <th style="color: white;">No</th>
                                            <th style="color: white;">Alternatif</th>
                                            <?php foreach ($kriteria as $header) : ?>
                                                <?php if ($header["nm_kriteria"] === "Kualitas Pengajar") : ?>
                                                    <th style="color: white;">Pelayanan</th>
                                                <?php elseif ($header["nm_kriteria"] === "Fasilitas") : ?>
                                                    <th style="color: white;">Makanan</th>
                                                <?php else : ?>
                                                    <th style="color: white;"><?= $header["nm_kriteria"] ?></th>
                                                <?php endif; ?>
                                            <?php endforeach ?>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $a = 1; ?>
                                        <?php foreach ($alternatif as $row) : ?>
                                            <tr>
                                                <td style="color: black;"><?= $a++ ?></td>
                                                <td style="color: black;"><?= $row["nm_les"] ?></td>
                                                <?php foreach ($kriteria as $k) : ?>
                                                    <?php 
                                                    $nilai = null;
                                                    foreach ($bobot as $pembobot) {
                                                        if ($pembobot["id_les"] == $row["id_les"] && $pembobot["id_kriteria"] == $k["id_kriteria"]) {
                                                            $nilai = $pembobot["nilai"];
                                                            break;
                                                        }
                                                    }
                                                    ?>
                                                    <td><?= $nilai ?></td>
                                                <?php endforeach ?>
                                            </tr>
                                        <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                            <hr>

                            <!-- BAGIAN -->
                            <h4 class="subtitle">Bagian 1 : Mencari Nilai W</h4>
                            <hr>
                            <p>Bobot Tiap Kriteria :</p>
                            <p>W = [
                                <?php foreach ($kriteria as $tampildoang) : ?>
                                    <?= $tampildoang["bobot"] . "," ?>
                                <?php endforeach ?>
                                ]
                            </p>
                            <hr>
                            <p>Pembobotan :</p>
                            <?php $b = 1 ?>
                            <?php foreach ($kriteria as $bagibobot) : ?>
                                <?php foreach ($maxkriteria as $TotalLah) : ?>
                                    <p>W<?= $b++ ?> =
                                        <?= $bagibobot["bobot"] . "/" . $TotalLah["Total"] ?> = <?= round($bagibobot["bobot"] / $TotalLah["Total"], 3) ?>
                                    </p>
                                <?php endforeach ?>
                            <?php endforeach ?>
                            <hr>
                            <p>Normalisasi Berdasarkan Pembobotan :</p>
                            <?php $c = 1 ?>
                            <?php foreach ($kriteria as $bagibobot) : ?>
                                <?php foreach ($maxkriteria as $TotalLah) : ?>
                                    <p>W<?= $c++ ?> =
                                        <?php if ($bagibobot["status"] == "COST") : ?>
                                            <?= round($bagibobot["bobot"] / $TotalLah["Total"], 3) * -1 ?></p>
                                <?php else : ?>
                                    <?= round($bagibobot["bobot"] / $TotalLah["Total"], 3) ?></p>
                                <?php endif ?>
                            <?php endforeach ?>
                        <?php endforeach ?>
                        <hr>

                        <!-- BAGIAN 2 -->
                        <h4 class="subtitle">Bagian 2 : Mencari Nilai Vector (S)</h4>
                        <p>Pembobotan :</p>
                        <?php $d = 1 ?>
                        <?php $e = 0 ?>
                        <?php foreach ($alternatif as $les) : ?>
                            <?php $idles = $les["id_les"] ?>
                            <?php $bobot = Index("SELECT * FROM pembobotan WHERE id_les = $idles"); ?>
                            <?php $test[$e] = 1 ?>
                            S<?= $d++ ?> =
                            <?php foreach ($bobot as $pembobot) : ?>
                                <?php $idbobot = $pembobot["id_kriteria"] ?>
                                <?php $kriteria = Index("SELECT * FROM kriteria WHERE id_kriteria = $idbobot"); ?>
                                <?php foreach ($kriteria as $bagibobot) : ?>
                                    <?php $maxkriteria = Index("SELECT SUM(bobot) AS Total FROM kriteria"); ?>
                                    <?php foreach ($maxkriteria as $TotalLah) : ?>
                                        <?php if ($bagibobot["status"] == "COST") : ?>
                                            (<?= $pembobot["nilai"] . "<sup>" . round($bagibobot["bobot"] / $TotalLah["Total"], 3) * -1 . "</sup>" ?>)
                                            <?php $test[$e] = $test[$e] * pow($pembobot["nilai"], round($bagibobot["bobot"] / $TotalLah["Total"], 3) * -1) ?>
                                        <?php else : ?>
                                            (<?= $pembobot["nilai"] . "<sup>" . round($bagibobot["bobot"] / $TotalLah["Total"], 3) . "</sup>" ?>)
                                            <?php $test[$e] = $test[$e] * pow($pembobot["nilai"], round($bagibobot["bobot"] / $TotalLah["Total"], 3)) ?>
                                        <?php endif ?>
                                    <?php endforeach ?>
                                <?php endforeach ?>
                            <?php endforeach ?>
                            =
                            <?= round($test[$e], 3) ?>
                            <?php $totalS = $totalS + $test[$e] ?>
                            <?php $e++ ?>
                            <br>
                        <?php endforeach ?>
                        <hr>
                        <h4 class="subtitle">Bagian 3 : Mencari Nilai V (V)</h4>
                        <?php $f = 1 ?>
                        <?php $g = 0 ?>
                        <?php foreach ($test as $row) : ?>
                            <p>V<?= $f++ ?> = <?= round($test[$g], 3) . "/" . round($totalS, 3) ?>
                                = <?= round(round($test[$g], 3) / round($totalS, 3), 3) ?></p>
                            <?php $g++ ?>
                        <?php endforeach ?>
                        <hr>
                        <h4 class="subtitle">Hasil</h4>
                        <?php 
                        // Mengumpulkan hasil akhir
                        $results = [];
                        foreach ($alternatif as $key => $row) {
                            $varV = $test[$key] / $totalS;
                            $results[] = [
                                'no' => $key + 1,
                                'alternatif' => $row["nm_les"],
                                'nilai' => round($varV, 3)
                            ];
                        }

                        // Mengurutkan hasil akhir berdasarkan nilai (desc)
                        usort($results, function($a, $b) {
                            return $b['nilai'] <=> $a['nilai'];
                        });

                        // Menambahkan ranking
                        foreach ($results as $key => &$result) {
                            $result['ranking'] = $key + 1;
                        }
                        ?>
                        <div class="table-container">
                            <table class="table is-fullwidth">
                                <thead>
                                    <tr style="background-color: #7D0541; color: white;">
                                        <th style="color: white;">No</th>
                                        <th style="color: white;">Alternatif</th>
                                        <th style="color: white;">Nilai</th>
                                        <th style="color: white;">Ranking</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr style="background-color: #7D0541; color: white;">
                                        <th style="color: white;">No</th>
                                        <th style="color: white;">Alternatif</th>
                                        <th style="color: white;">Nilai</th>
                                        <th style="color: white;">Ranking</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php foreach ($results as $result) : ?>
                                        <tr>
                                            <td style="color: black;"><?= $result['no'] ?></td>
                                            <td style="color: black;"><?= $result['alternatif'] ?></td>
                                            <td><?= $result['nilai'] ?></td>
                                            <td><?= $result['ranking'] ?></td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
